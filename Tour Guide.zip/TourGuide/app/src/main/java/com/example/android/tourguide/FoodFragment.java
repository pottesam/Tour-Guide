package com.example.android.tourguide;


import android.location.Location;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import java.util.ArrayList;


public class FoodFragment extends Fragment {


    public FoodFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.activity_food, container, false);

        final ArrayList<Local> locationFood = new ArrayList<Local>();

        locationFood.add(new Local("122 Blagden Alley NW", "The Dabney"));
        locationFood.add(new Local("1601 14th St. NW", "Le Diplomate"));
        locationFood.add(new Local("1346 Florida Ave NW", "Maydan"));
        locationFood.add(new Local("1015 7th St. NW", "Kinship"));
        locationFood.add(new Local("701 9th St. NW", "Zaytinya"));
        locationFood.add(new Local("3226 11th St. NW", "Bad Saint"));
        locationFood.add(new Local("791 Wharf St. SW", "Del Mar"));
        locationFood.add(new Local("mustard 1201 24th St. NW", "Blue Duck Tavern"));


        // Create an {@link WordAdapter}, whose data source is a list of {@link Word}s. The
        // adapter knows how to create list items for each item in the list.
        LocationAdapter adapter = new LocationAdapter(getActivity(), locationFood);

        // Find the {@link ListView} object in the view hierarchy of the {@link Activity}.
        // There should be a {@link ListView} with the view ID called list, which is declared in the
        // activity_numbers.xml layout file.
        ListView listView = (ListView) rootView.findViewById(R.id.list);

        // Make the {@link ListView} use the {@link WordAdapter} we created above, so that the
        // {@link ListView} will display list items for each {@link Word} in the list.
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Local local = locationFood.get(position);
            }
        });
        return rootView;
    }
}

