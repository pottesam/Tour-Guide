package com.example.android.tourguide;


//ADD PICTURES TO HISTORY FRAGMENT CHECK MIWOK FOR HELP

import android.location.Location;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import java.util.ArrayList;


public class HistoryFragment extends Fragment {


    public HistoryFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.activity_food, container, false);

        final ArrayList<Local> locationHistory = new ArrayList<Local>();

        locationHistory.add(new Local("2 Lincoln Memorial Cir NW", "Lincoln Memorial"));
        locationHistory.add(new Local("First St. SE", "United States Capitol"));
        locationHistory.add(new Local("2 15th St. NW", "Washington Monument"));
        locationHistory.add(new Local("1300 Constitution Ave NW", "Museum of American History"));
        locationHistory.add(new Local("10th St. & Constitution NW", "Museum of Natural History"));
        locationHistory.add(new Local("1 Memorial Ave", "Arlington Cemetery"));
        locationHistory.add(new Local("900 Ohio Dr SW", "Korean War Memorial"));
        locationHistory.add(new Local("1600 Pennsylvania Ave", "The White House"));


        // Create an {@link WordAdapter}, whose data source is a list of {@link Word}s. The
        // adapter knows how to create list items for each item in the list.
        LocationAdapter adapter = new LocationAdapter(getActivity(), locationHistory);

        // Find the {@link ListView} object in the view hierarchy of the {@link Activity}.
        // There should be a {@link ListView} with the view ID called list, which is declared in the
        // activity_numbers.xml layout file.
        ListView listView = (ListView) rootView.findViewById(R.id.list);

        // Make the {@link ListView} use the {@link WordAdapter} we created above, so that the
        // {@link ListView} will display list items for each {@link Word} in the list.
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Local local = locationHistory.get(position);
            }
        });
        return rootView;
    }
}

