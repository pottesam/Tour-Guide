package com.example.android.tourguide;

public class Local {

    private int mImageResourceId = NO_IMAGE_PROVIDED;

    private String mLocationAddress;

    private String mLocationName;

    private static final int NO_IMAGE_PROVIDED = -1;



    public Local(String locationAddress, String locationName ) {
        mLocationAddress = locationAddress;
        mLocationName = locationName;
    }

    public Local(String locationAddress, String locationName, int ImageResourceId) {
        mLocationAddress = locationAddress;
        mLocationName = locationName;
        mImageResourceId = ImageResourceId;
    }

    public String getLocationAddress() {
        return mLocationAddress;
    }

    public String getLocationName() {
        return mLocationName;
    }

    public int getmImageResourceId() {
        return mImageResourceId;
    }

    public boolean hasImage(){
        return mImageResourceId != NO_IMAGE_PROVIDED;
    }



}
