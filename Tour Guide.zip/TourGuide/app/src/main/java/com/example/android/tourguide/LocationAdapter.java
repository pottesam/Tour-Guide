package com.example.android.tourguide;

import android.content.Context;

import android.location.Location;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.example.android.tourguide.R;

import java.util.ArrayList;

public class LocationAdapter extends ArrayAdapter<Local> {


    public LocationAdapter(Context context, ArrayList<Local> pWords) {
        super(context,0, pWords);
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        // Check if the existing view is being reused, otherwise inflate the view
        View listItemView = convertView;

        if(listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.list_item, parent, false);
        }
        Local currentLocal = getItem(position);
        TextView nameTextView = (TextView) listItemView.findViewById(R.id.name_text_view);
        nameTextView.setText(currentLocal.getLocationName());

        TextView defaultTextView = (TextView) listItemView.findViewById(R.id.address_text_view);
        defaultTextView.setText(currentLocal.getLocationAddress());

        //find the imageview in the list_item.xml
        ImageView imageView = (ImageView) listItemView.findViewById(R.id.image);
        if(currentLocal.hasImage()) {
            // set the imageview to the image resource specified in the current Word
            imageView.setImageResource(currentLocal.getmImageResourceId());
            // make sure the view is visible
            imageView.setVisibility(View.VISIBLE);
        }
        else{
            //make sure the view is hidden and not taking up space in the view
            imageView.setVisibility(View.GONE);
        }

        // set the theme color for the list item
        View textContainer = listItemView.findViewById(R.id.text_container);

        return listItemView;
    }
}
