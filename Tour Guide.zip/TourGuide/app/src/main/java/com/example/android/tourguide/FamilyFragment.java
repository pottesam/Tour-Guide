package com.example.android.tourguide;


import android.location.Location;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import java.util.ArrayList;


public class FamilyFragment extends Fragment {


    public FamilyFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.activity_food, container, false);

        final ArrayList<Local> locationFamily = new ArrayList<Local>();

        locationFamily.add(new Local("3001 Connecticut Ave NW", "The National Zoo"));
        locationFamily.add(new Local("1001 F St. NW", "Madame Tussauds"));
        locationFamily.add(new Local("1450 Pennsylvania Ave NW", "The President's Park"));
        locationFamily.add(new Local("100 Maryland Ave SW", "Botanic Gardens"));
        locationFamily.add(new Local("Constitution Ave NW", "Constitutional Gardens"));
        locationFamily.add(new Local("3303 Water St. NW", "Georgetown Waterfront Park"));
        locationFamily.add(new Local("Constitutional Ave NW", "National Gallery of Art"));
        locationFamily.add(new Local("15th St. NW & E St. NW", "National Christmas Tree"));


        // Create an {@link WordAdapter}, whose data source is a list of {@link Word}s. The
        // adapter knows how to create list items for each item in the list.
        LocationAdapter adapter = new LocationAdapter(getActivity(), locationFamily);

        // Find the {@link ListView} object in the view hierarchy of the {@link Activity}.
        // There should be a {@link ListView} with the view ID called list, which is declared in the
        // activity_numbers.xml layout file.
        ListView listView = (ListView) rootView.findViewById(R.id.list);

        // Make the {@link ListView} use the {@link WordAdapter} we created above, so that the
        // {@link ListView} will display list items for each {@link Word} in the list.
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Local local = locationFamily.get(position);
            }
        });
        return rootView;
    }
}

